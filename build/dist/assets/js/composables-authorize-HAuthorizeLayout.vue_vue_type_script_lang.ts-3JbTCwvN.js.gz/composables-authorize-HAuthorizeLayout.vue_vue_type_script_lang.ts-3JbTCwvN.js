import{d as e}from"./npm-@vue-runtime-core-Bpel2nBe.js";const t=e({name:"HAuthorizeLayout",props:{overlay:{type:Boolean,default:!1},title:{type:String,default:""}}});export{t as _};
