import{r as t}from"./npm-function-bind-CHqF18-c.js";var r,a;function s(){if(a)return r;a=1;var n=Function.prototype.call,o=Object.prototype.hasOwnProperty,e=t();return r=e.call(n,o),r}export{s as r};
