import"./configurations-constants.ts-STGhZzJt.js";import"./configurations-variables.ts-CrWc6tFp.js";import"./configurations-http.ts-B_udfUNp.js";
