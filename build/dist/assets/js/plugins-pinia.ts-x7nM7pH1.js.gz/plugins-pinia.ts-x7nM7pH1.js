import{c as s}from"./npm-pinia-CSWXeOJ2.js";import{i}from"./npm-pinia-plugin-persistedstate-DVWheEap.js";const p=s();p.use(i);const t=s=>{s.use(p)};export{t as s};
